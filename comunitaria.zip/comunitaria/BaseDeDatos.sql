-- Creación de la base de datos
CREATE DATABASE IF NOT EXISTS comunitaria;
USE comunitaria;

-- Tabla de Usuarios
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de Eventos
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    location VARCHAR(200) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de Comentarios
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    event_id INT NOT NULL,
    comment TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

-- Insertar datos de ejemplo para usuarios
INSERT INTO users (name, email, password, role) VALUES
('Admin User', 'admin@comunitaria.com', '$2y$10$sZC.a/.4J/U5ROXhbKrwhe5LRFZo7H2HH1l6zpADeUke1Ioy78mBe', 'admin'),
('Regular User', 'user@comunitaria.com', '$2y$10$mpDLg3e.Nkw6GlH2N9/6U.7VJ1S8c5K3PLOxIjUMdrA3ycf0Ypwsm', 'user');

-- Insertar datos de ejemplo para eventos
INSERT INTO events (title, description, date, time, location) VALUES
('Festival de la Comunidad', 'Un evento para celebrar la diversidad y la unión de la comunidad local.', '2024-11-01', '18:00:00', 'Plaza Central'),
('Taller de Reciclaje', 'Aprende a reciclar y contribuir al medio ambiente en este taller educativo.', '2024-11-05', '10:00:00', 'Centro de Recursos Ecológicos');

-- Insertar datos de ejemplo para comentarios
INSERT INTO comments (user_id, event_id, comment, rating) VALUES
(2, 1, '¡Fue un evento maravilloso! Muy bien organizado.', 5),
(2, 2, 'Aprendí mucho sobre reciclaje. Muy educativo.', 4);
