<?php
include '../includes/db.php';
session_start();

// Verificar si el usuario es administrador
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: /comunitaria/users/login.php");
    exit();
}

// Procesar el formulario para crear un evento
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_event'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $location = $_POST['location'];

    $sql = "INSERT INTO events (title, description, date, time, location) VALUES ('$title', '$description', '$date', '$time', '$location')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert alert-success text-center'>Evento creado exitosamente.</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Error: " . $conn->error . "</div>";
    }
}

// Procesar solicitud para eliminar un evento
if (isset($_GET['delete'])) {
    $event_id = $_GET['delete'];
    $delete_sql = "DELETE FROM events WHERE id = $event_id";
    
    if ($conn->query($delete_sql) === TRUE) {
        echo "<div class='alert alert-success text-center'>Evento eliminado exitosamente.</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Error al eliminar el evento: " . $conn->error . "</div>";
    }
}

// Obtener la lista de eventos
$events_sql = "SELECT * FROM events ORDER BY date ASC";
$events_result = $conn->query($events_sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Eventos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="container my-5">
        <h2 class="text-center mb-4">Administración de Eventos</h2>

        <!-- Formulario para Crear un Evento -->
        <div class="card mb-5">
            <div class="card-header">
                <h3>Crear Evento</h3>
            </div>
            <div class="card-body">
                <form method="post">
                    <div class="mb-3">
                        <label for="title" class="form-label">Título del Evento</label>
                        <input type="text" class="form-control" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Descripción</label>
                        <textarea class="form-control" name="description" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Fecha</label>
                        <input type="date" class="form-control" name="date" required>
                    </div>
                    <div class="mb-3">
                        <label for="time" class="form-label">Hora</label>
                        <input type="time" class="form-control" name="time" required>
                    </div>
                    <div class="mb-3">
                        <label for="location" class="form-label">Ubicación</label>
                        <input type="text" class="form-control" name="location" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" name="create_event" class="btn btn-primary">Crear Evento</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Listado de Eventos Existentes -->
        <h3 class="text-center mb-4">Eventos Existentes</h3>
        <?php if ($events_result->num_rows > 0): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Ubicación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($event = $events_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $event['id']; ?></td>
                        <td><?php echo $event['title']; ?></td>
                        <td><?php echo $event['date']; ?></td>
                        <td><?php echo $event['time']; ?></td>
                        <td><?php echo $event['location']; ?></td>
                        <td>
                            <a href="/comunitaria/admin/admin.php?delete=<?php echo $event['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar este evento?');">Eliminar</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-center">No hay eventos disponibles.</p>
        <?php endif; ?>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
