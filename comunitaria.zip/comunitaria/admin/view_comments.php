<?php
include '../includes/db.php';
session_start();

// Verificar si el usuario es administrador
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: /comunitaria/users/login.php");
    exit();
}

$event_id = isset($_GET['event_id']) ? (int)$_GET['event_id'] : 0;

// Verificar si el ID del evento es válido
if ($event_id <= 0) {
    echo "<div class='alert alert-danger text-center'>ID de evento no válido.</div>";
    exit();
}

// Obtener los comentarios del evento
$sql = "SELECT c.id, c.comment, c.rating, c.created_at, c.response, u.name AS user_name 
        FROM comments c 
        JOIN users u ON c.user_id = u.id 
        WHERE c.event_id = $event_id 
        ORDER BY c.created_at DESC";

$comments_result = $conn->query($sql);

// Verificar si la consulta se ejecutó correctamente
if (!$comments_result) {
    echo "<div class='alert alert-danger text-center'>Error al obtener los comentarios: " . $conn->error . "</div>";
    exit();
}

// Procesar la respuesta del administrador
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['respond'])) {
    $comment_id = $_POST['comment_id'];
    $response = $_POST['response'];

    $update_sql = "UPDATE comments SET response = '$response' WHERE id = $comment_id";

    if ($conn->query($update_sql) === TRUE) {
        echo "<div class='alert alert-success text-center'>Respuesta enviada exitosamente.</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Error al enviar la respuesta: " . $conn->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comentarios del Evento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="container my-5">
        <h2 class="text-center mb-4">Comentarios del Evento</h2>
        <?php if ($comments_result->num_rows > 0): ?>
            <ul class="list-group mb-5">
                <?php while ($comment = $comments_result->fetch_assoc()): ?>
                <li class="list-group-item">
                    <p><strong><?php echo $comment['user_name']; ?></strong> dijo:</p>
                    <p><?php echo $comment['comment']; ?></p>
                    <p><strong>Valoración:</strong> <?php echo str_repeat("⭐", $comment['rating']); ?></p>
                    <p><small class="text-muted">Publicado el <?php echo date("d/m/Y", strtotime($comment['created_at'])); ?></small></p>
                    <?php if ($comment['response']): ?>
                        <p><strong>Respuesta del Admin:</strong> <?php echo $comment['response']; ?></p>
                    <?php endif; ?>

                    <!-- Formulario para Responder -->
                    <form method="post" class="mt-3">
                        <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                        <div class="mb-3">
                            <textarea class="form-control" name="response" rows="2" placeholder="Responder comentario..." required></textarea>
                        </div>
                        <button type="submit" name="respond" class="btn btn-primary btn-sm">Enviar Respuesta</button>
                    </form>
                </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="text-center">No hay comentarios para este evento.</p>
        <?php endif; ?>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
