document.addEventListener("DOMContentLoaded", function () {
    var carousel = new bootstrap.Carousel(document.querySelector('#carouselBanner'), {
        interval: 3000, // Cambiar imagen cada 3 segundos
        wrap: true      // Volver al inicio después de la última imagen
    });
});
