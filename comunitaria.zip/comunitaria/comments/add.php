<?php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /comunitaria/users/login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_id = $_POST['event_id'];
    $comment = $_POST['comment'];
    $rating = $_POST['rating'];
    $user_id = $_SESSION['user_id'];

    $sql = "INSERT INTO comments (user_id, event_id, comment, rating) VALUES ($user_id, $event_id, '$comment', $rating)";

    if ($conn->query($sql) === TRUE) {
        header("Location: /comunitaria/events/view.php?id=$event_id");
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>
