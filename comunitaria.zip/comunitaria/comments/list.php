<?php
include '../includes/db.php';

// Verificar que se haya proporcionado un ID de evento válido
$event_id = isset($event_id) ? $event_id : 0;

if ($event_id == 0) {
    echo "<p>No se han encontrado comentarios porque el evento no es válido.</p>";
    return;
}

// Obtener los comentarios del evento
$sql = "SELECT c.comment, c.rating, c.created_at, u.name AS user_name 
        FROM comments c 
        JOIN users u ON c.user_id = u.id 
        WHERE c.event_id = $event_id 
        ORDER BY c.created_at DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($comment = $result->fetch_assoc()) {
        ?>
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title"><?php echo $comment['user_name']; ?></h5>
                <p class="card-text"><?php echo $comment['comment']; ?></p>
                <p class="card-text">
                    <strong>Valoración:</strong> 
                    <?php echo str_repeat("⭐", $comment['rating']); ?>
                </p>
                <p class="card-text">
                    <small class="text-muted">Publicado el <?php echo date("d/m/Y", strtotime($comment['created_at'])); ?></small>
                </p>
            </div>
        </div>
        <?php
    }
} else {
    echo "<p>No hay comentarios para este evento.</p>";
}
?>
