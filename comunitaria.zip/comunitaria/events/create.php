<?php
include '../includes/db.php';
session_start();

if ($_SESSION['role'] != 'admin') {
    echo "Acceso denegado.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $location = $_POST['location'];
    $created_by = $_SESSION['user_id'];

    $sql = "INSERT INTO events (title, description, date, time, location, created_by) 
            VALUES ('$title', '$description', '$date', '$time', '$location', $created_by)";

    if ($conn->query($sql) === TRUE) {
        echo "Evento creado exitosamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de Eventos Comunitarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>


<form method="post">
    Título: <input type="text" name="title" required><br>
    Descripción: <textarea name="description" required></textarea><br>
    Fecha: <input type="date" name="date" required><br>
    Hora: <input type="time" name="time" required><br>
    Ubicación: <input type="text" name="location" required><br>
    <input type="submit" value="Crear Evento">
</form>
