<?php
include '../includes/db.php';
session_start();

if ($_SESSION['role'] != 'admin') {
    echo "Acceso denegado.";
    exit;
}

$event_id = $_GET['id'];
$sql = "SELECT * FROM events WHERE id = $event_id";
$result = $conn->query($sql);
$event = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $location = $_POST['location'];

    $update_sql = "UPDATE events SET title='$title', description='$description', date='$date', time='$time', location='$location' WHERE id=$event_id";

    if ($conn->query($update_sql) === TRUE) {
        echo "Evento actualizado exitosamente.";
        header("Location: /events/view.php?id=$event_id");
    } else {
        echo "Error: " . $update_sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Evento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="/">Portal de Eventos</a>
        </div>
    </nav>

    <div class="container">
        <h2>Editar Evento</h2>
        <form method="post" class="col-md-6 offset-md-3">
            <div class="mb-3">
                <label for="title" class="form-label">Título</label>
                <input type="text" class="form-control" name="title" value="<?php echo $event['title']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Descripción</label>
                <textarea class="form-control" name="description" required><?php echo $event['description']; ?></textarea>
            </div>
            <div class="mb-3">
                <label for="date" class="form-label">Fecha</label>
                <input type="date" class="form-control" name="date" value="<?php echo $event['date']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="time" class="form-label">Hora</label>
                <input type="time" class="form-control" name="time" value="<?php echo $event['time']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="location" class="form-label">Ubicación</label>
                <input type="text" class="form-control" name="location" value="<?php echo $event['location']; ?>" required>
            </div>
            <input type="submit" class="btn btn-primary w-100" value="Actualizar Evento">
        </form>
    </div>

    <footer class="footer">
        <p>© 2024 Portal de Eventos Comunitarios</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
