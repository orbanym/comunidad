<?php
include '../includes/db.php';
include '../includes/header.php';  // Incluir el header

$sql = "SELECT * FROM events ORDER BY date ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos - Portal de Eventos Comunitarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2 class="my-4">Eventos Disponibles</h2>
        <div class="row">
            <?php
            if ($result->num_rows > 0) {
                while ($event = $result->fetch_assoc()) {
                    ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $event['title']; ?></h5>
                                <p class="card-text">
                                    <?php echo substr($event['description'], 0, 100) . '...'; ?>
                                </p>
                                <p class="card-text"><strong>Fecha:</strong> <?php echo $event['date']; ?></p>
                                <p class="card-text"><strong>Hora:</strong> <?php echo $event['time']; ?></p>
                                <a href="/comunitaria/events/view.php?id=<?php echo $event['id']; ?>" class="btn btn-primary">Ver Detalles</a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p>No hay eventos disponibles en este momento.</p>";
            }
            $conn->close();
            ?>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>  <!-- Incluir el footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
