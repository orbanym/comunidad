<?php
include '../includes/db.php';
session_start();

$event_id = isset($_GET['id']) ? $_GET['id'] : 0;

// Verificar que se haya proporcionado un ID de evento válido
if ($event_id == 0) {
    echo "Evento no válido.";
    exit;
}

// Obtener los detalles del evento
$sql = "SELECT * FROM events WHERE id = $event_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "Evento no encontrado.";
    exit;
}

$event = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $event['title']; ?> - Portal de Eventos Comunitarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="container">
        <h2 class="my-4"><?php echo $event['title']; ?></h2>
        <p><strong>Fecha:</strong> <?php echo $event['date']; ?></p>
        <p><strong>Hora:</strong> <?php echo $event['time']; ?></p>
        <p><strong>Ubicación:</strong> <?php echo $event['location']; ?></p>
        <p><?php echo $event['description']; ?></p>

        <h3 class="my-4">Comentarios</h3>
        <?php include '../comments/list.php'; ?>

        <?php if (isset($_SESSION['user_id'])): ?>
        <h4 class="my-4">Deja tu comentario</h4>
        <form method="post" action="/comunitaria/comments/add.php" class="mb-4">
            <input type="hidden" name="event_id" value="<?php echo $event_id; ?>">
            <div class="mb-3">
                <label for="comment" class="form-label">Comentario</label>
                <textarea class="form-control" name="comment" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="rating" class="form-label">Valoración (1-5)</label>
                <select name="rating" class="form-control" required>
                    <option value="1">1 Estrella</option>
                    <option value="2">2 Estrellas</option>
                    <option value="3">3 Estrellas</option>
                    <option value="4">4 Estrellas</option>
                    <option value="5">5 Estrellas</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Enviar Comentario</button>
        </form>
        <?php else: ?>
        <p><a href="/comunitaria/users/login.php">Inicia sesión</a> para dejar un comentario.</p>
        <?php endif; ?>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
