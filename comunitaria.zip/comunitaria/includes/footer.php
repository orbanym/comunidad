<footer class="footer bg-primary text-white text-center py-3">
    <p>© 2024 Portal de Eventos Comunitarios</p>
    <p>By Orbany Marine Delgado Matricula: 100049998</p>
</footer>
