<?php
include 'includes/db.php';
include 'includes/header.php';

// Obtener todos los eventos de la base de datos
$events_sql = "SELECT * FROM events ORDER BY date ASC";
$events_result = $conn->query($events_sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de Eventos Comunitarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/comunitaria/assets/css/style.css">
</head>
<body>
    

    <!-- Carrusel de Banner -->
    <div id="carouselBanner" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="/comunitaria/assets/images/banner1.jpg" class="d-block w-100 banner-img" alt="Evento Comunitario 1">
            </div>
            <div class="carousel-item">
                <img src="/comunitaria/assets/images/banner2.jpg" class="d-block w-100 banner-img" alt="Evento Comunitario 2">
            </div>
            <div class="carousel-item">
                <img src="/comunitaria/assets/images/banner3.jpg" class="d-block w-100 banner-img" alt="Evento Comunitario 3">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselBanner" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselBanner" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Descripción Creativa -->
    <div class="container my-5 text-center">
        <h1 class="mb-4">Bienvenidos al Portal de Eventos Comunitarios</h1>
        <p class="lead">
            ¡Descubre y participa en eventos increíbles que unen a nuestra comunidad! Desde festivales locales hasta ferias de artesanías, talleres educativos y actividades recreativas, 
            nuestros eventos están diseñados para conectar a personas, compartir experiencias y crear recuerdos inolvidables. Explora y sé parte de la magia que transforma nuestros vecindarios. 
            ¡Tu presencia es lo que hace que cada evento sea especial!
        </p>
    </div>

    <!-- Listado de Eventos Existentes -->
    <div class="container my-5">
        <h3 class="text-center mb-4">Eventos Disponibles</h3>
        <div class="row">
            <?php if ($events_result->num_rows > 0): ?>
                <?php while ($event = $events_result->fetch_assoc()): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $event['title']; ?></h5>
                            <p class="card-text">
                                <?php echo substr($event['description'], 0, 100) . '...'; ?>
                            </p>
                            <p class="card-text"><strong>Fecha:</strong> <?php echo $event['date']; ?></p>
                            <p class="card-text"><strong>Hora:</strong> <?php echo $event['time']; ?></p>
                            <a href="/comunitaria/events/view.php?id=<?php echo $event['id']; ?>" class="btn btn-primary">Ver Detalles</a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-center">No hay eventos disponibles en este momento.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/comunitaria/assets/js/carousel.js"></script>
</body>
</html>
