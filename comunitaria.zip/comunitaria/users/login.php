<?php
include '../includes/db.php';
include '../includes/header.php';  // Incluir el header

// Verificar si la sesión ya está iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirigir a los usuarios logueados fuera de la página de login
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] == 'admin') {
        header("Location: /comunitaria/admin/admin.php");
    } else {
        header("Location: /comunitaria/events/reader.php");
    }
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            // Redirigir según el rol del usuario
            if ($user['role'] == 'admin') {
                header("Location: /comunitaria/admin/admin.php");
            } else {
                header("Location: /comunitaria/events/reader.php");
            }
            exit();
        } else {
            echo "<div class='alert alert-danger text-center'>Contraseña incorrecta.</div>";
        }
    } else {
        echo "<div class='alert alert-danger text-center'>Usuario no encontrado.</div>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container d-flex flex-column align-items-center justify-content-center" style="min-height: 80vh;">
        <h2 class="mb-4 text-center">Iniciar Sesión</h2>
        <div class="card col-md-6 p-4">
            <form method="post">
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <div class="text-center">
                    <input type="submit" class="btn btn-primary btn-lg px-5" value="Iniciar Sesión">
                </div>
            </form>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>  <!-- Incluir el footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
