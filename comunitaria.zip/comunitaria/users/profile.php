<?php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /users/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Obtener los datos del usuario
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Actualizar información del perfil
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $update_sql = "UPDATE users SET name='$name', email='$email' WHERE id=$user_id";
    if ($conn->query($update_sql) === TRUE) {
        echo "<div class='alert alert-success'>Perfil actualizado exitosamente.</div>";
        header("Refresh:1");
    } else {
        echo "<div class='alert alert-danger'>Error al actualizar el perfil: " . $conn->error . "</div>";
    }
}

// Cambiar contraseña
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (password_verify($current_password, $user['password'])) {
        if ($new_password === $confirm_password) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_password_sql = "UPDATE users SET password='$hashed_password' WHERE id=$user_id";
            if ($conn->query($update_password_sql) === TRUE) {
                echo "<div class='alert alert-success'>Contraseña actualizada exitosamente.</div>";
            } else {
                echo "<div class='alert alert-danger'>Error al actualizar la contraseña.</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Las contraseñas nuevas no coinciden.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>La contraseña actual es incorrecta.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - Portal de Eventos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="container">
        <h2 class="my-4">Mi Perfil</h2>

        <form method="post" class="col-md-6 offset-md-3 mb-4">
            <h3>Información del Perfil</h3>
            <div class="mb-3">
                <label for="name" class="form-label">Nombre</label>
                <input type="text" class="form-control" name="name" value="<?php echo $user['name']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Correo Electrónico</label>
                <input type="email" class="form-control" name="email" value="<?php echo $user['email']; ?>" required>
            </div>
            <input type="submit" class="btn btn-primary w-100" name="update_profile" value="Actualizar Perfil">
        </form>

        <form method="post" class="col-md-6 offset-md-3">
            <h3>Cambiar Contraseña</h3>
            <div class="mb-3">
                <label for="current_password" class="form-label">Contraseña Actual</label>
                <input type="password" class="form-control" name="current_password" required>
            </div>
            <div class="mb-3">
                <label for="new_password" class="form-label">Nueva Contraseña</label>
                <input type="password" class="form-control" name="new_password" required>
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirmar Nueva Contraseña</label>
                <input type="password" class="form-control" name="confirm_password" required>
            </div>
            <input type="submit" class="btn btn-secondary w-100" name="change_password" value="Cambiar Contraseña">
        </form>
    </div>

    <footer class="footer">
        <p>© 2024 Portal de Eventos Comunitarios</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
