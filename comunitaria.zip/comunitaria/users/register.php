<?php
include '../includes/db.php';
include '../includes/header.php';  // Incluir el header

$showSuccessModal = false;  // Variable para controlar el popup

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Verificar si el correo ya existe
    $checkEmailSql = "SELECT * FROM users WHERE email = '$email'";
    $checkEmailResult = $conn->query($checkEmailSql);

    if ($checkEmailResult->num_rows > 0) {
        echo "<div class='alert alert-danger text-center'>El correo electrónico ya está registrado. Por favor, utiliza otro.</div>";
    } else {
        // Insertar el nuevo usuario si el correo no está registrado
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";

        if ($conn->query($sql) === TRUE) {
            $showSuccessModal = true;  // Activar el popup en caso de éxito
        } else {
            echo "<div class='alert alert-danger text-center'>Error: " . $conn->error . "</div>";
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container d-flex flex-column align-items-center justify-content-center" style="min-height: 80vh;">
        <h2 class="mb-4 text-center">Registro de Usuario</h2>
        <div class="card col-md-6 p-4">
            <form method="post">
                <div class="mb-3">
                    <label for="name" class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <div class="text-center">
                    <input type="submit" class="btn btn-primary btn-lg px-5" value="Registrar">
                </div>
            </form>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>  <!-- Incluir el footer -->

    <!-- Modal de éxito -->
    <?php if ($showSuccessModal): ?>
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Registro Exitoso</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ¡Tu registro se ha completado con éxito, ya puede iniciar sección!
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Aceptar</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mostrar el modal de éxito
        document.addEventListener('DOMContentLoaded', function() {
            var successModal = new bootstrap.Modal(document.getElementById('successModal'));
            successModal.show();

            // Redirigir al index después de 3 segundos
            setTimeout(function() {
                window.location.href = '/comunitaria/users/login.php';
            }, 3000);
        });
    </script>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
